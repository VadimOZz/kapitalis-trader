
import os
import logging
import asyncio
from aiogram import Bot, Dispatcher, types
from tinkoff.invest import Client

BOT_TOKEN = os.getenv("BOT_TOKEN")
TINKOFF_TOKEN = os.getenv("TINKOFF_TOKEN")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

@dp.message()
async def handle_message(message: types.Message):
    if message.text == "/start":
        await message.answer("Капиталис подключён ✅")
    elif message.text == "/портфель":
        try:
            with Client(TINKOFF_TOKEN) as client:
                accounts = client.users.get_accounts()
                account_id = accounts.accounts[0].id
                positions = client.operations.get_portfolio(account_id=account_id)
                text = "📊 Твой портфель:\n"
                for p in positions.positions:
                    figi = p.figi
                    name = client.instruments.get_instrument_by(id_type=1, id=figi).instrument.name
                    quantity = p.quantity.units
                    value = p.current_price.units + p.current_price.nano / 1e9
                    text += f"- {name}: {quantity} шт ≈ {value:.2f} ₽\n"
                await message.answer(text)
        except Exception as e:
            await message.answer("Ошибка при получении портфеля.")

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
